﻿using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ApiProject;
using ApiProject.Controllers;
//using NUnit.Framework;
//using MVC5_Testing_1.Controllers;
//using System.Web.Mvc;
//using MVC5_Testing_1.Models;

namespace ApiProject.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        [TestMethod]
        public void Index()
        {
            // Arrange
            var controller = new PeopleController();

            // Act
            var result = controller.Get(1) ;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Neha", result.firstName);
        }
    }
}
